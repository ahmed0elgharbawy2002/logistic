import type { Trip, TruckEntry, SimpleEntry } from '../types';

const TRIPS_KEY = 'feed-truck-trips';
const TRUCKS_KEY = 'feed-truck-trucks';
const FARMS_KEY = 'feed-truck-farms';
const FEED_TYPES_KEY = 'feed-truck-feedtypes';

/**
 * أسماء المراحل في النسخة القديمة من البرنامج.
 * "دخول المصنع" القديمة = دخول الشاحنة للتحميل، أي "بداية التحميل" الآن.
 */
const LEGACY_STAGE_MAP: Record<string, string> = {
  factoryEnter: 'loadingStart',
  departureToDestination: 'departure',
};

const VALID_STAGES = new Set<string>([
  'gateArrival',
  'loadingStart',
  'departure',
  'farmArrival',
  'unloadingDone',
  'factoryReturn',
]);

/** يحوّل أي رحلة (حتى من نسخة قديمة) إلى الشكل الحالي */
export function normalizeTrip(t: Trip): Trip {
  const copy: Record<string, unknown> = { ...t };
  // حقول كانت تُخزَّن سابقاً وأصبحت تُحسب تلقائياً
  delete copy.status;
  delete copy.totalDuration;
  delete copy.breakdownDuration;

  const stages: Record<string, string> = {};
  for (const [key, value] of Object.entries(t.stages ?? {})) {
    const mapped = LEGACY_STAGE_MAP[key] ?? key;
    if (typeof value === 'string' && VALID_STAGES.has(mapped)) stages[mapped] = value;
  }
  return {
    ...(copy as unknown as Trip),
    tripNumber: t.tripNumber ?? '',
    stages,
    breakdowns: Array.isArray(t.breakdowns) ? t.breakdowns : [],
    createdAt: t.createdAt ?? new Date().toISOString(),
  };
}

export function loadTrips(): Trip[] {
  try {
    const raw = localStorage.getItem(TRIPS_KEY);
    if (!raw) return [];
    const parsed = JSON.parse(raw) as Trip[];
    if (!Array.isArray(parsed)) return [];
    return parsed.map(normalizeTrip);
  } catch {
    return [];
  }
}

export function saveTrips(trips: Trip[]): void {
  try {
    localStorage.setItem(TRIPS_KEY, JSON.stringify(trips));
  } catch (e) {
    console.error('Failed to save trips', e);
  }
}

export function loadTrucks(): TruckEntry[] {
  try {
    const raw = localStorage.getItem(TRUCKS_KEY);
    if (!raw) return [];
    const parsed = JSON.parse(raw) as TruckEntry[];
    if (!Array.isArray(parsed)) return [];
    return parsed;
  } catch {
    return [];
  }
}

export function saveTrucks(trucks: TruckEntry[]): void {
  try {
    localStorage.setItem(TRUCKS_KEY, JSON.stringify(trucks));
  } catch (e) {
    console.error('Failed to save trucks', e);
  }
}

export function loadFarms(): SimpleEntry[] {
  try {
    const raw = localStorage.getItem(FARMS_KEY);
    if (!raw) return [];
    const parsed = JSON.parse(raw) as SimpleEntry[];
    if (!Array.isArray(parsed)) return [];
    return parsed;
  } catch {
    return [];
  }
}

export function saveFarms(farms: SimpleEntry[]): void {
  try {
    localStorage.setItem(FARMS_KEY, JSON.stringify(farms));
  } catch (e) {
    console.error('Failed to save farms', e);
  }
}

export function loadFeedTypes(): SimpleEntry[] {
  try {
    const raw = localStorage.getItem(FEED_TYPES_KEY);
    if (!raw) return [];
    const parsed = JSON.parse(raw) as SimpleEntry[];
    if (!Array.isArray(parsed)) return [];
    return parsed;
  } catch {
    return [];
  }
}

export function saveFeedTypes(feedTypes: SimpleEntry[]): void {
  try {
    localStorage.setItem(FEED_TYPES_KEY, JSON.stringify(feedTypes));
  } catch (e) {
    console.error('Failed to save feed types', e);
  }
}
