import type { Trip, TruckEntry, SimpleEntry } from '../types';
import { normalizeTrip } from './storage';

export interface BackupData {
  app: 'feed-trips-tracker';
  version: 1;
  exportedAt: string;
  trips: Trip[];
  trucks: TruckEntry[];
  farms: SimpleEntry[];
  feedTypes: SimpleEntry[];
}

export interface AppData {
  trips: Trip[];
  trucks: TruckEntry[];
  farms: SimpleEntry[];
  feedTypes: SimpleEntry[];
}

export interface MergeResult extends AppData {
  addedTrips: number;
  skippedTrips: number;
  addedTrucks: number;
  addedFarms: number;
  addedFeedTypes: number;
}

/** تنزيل نسخة احتياطية كاملة من البيانات كملف JSON */
export function downloadBackup(data: AppData): void {
  const backup: BackupData = {
    app: 'feed-trips-tracker',
    version: 1,
    exportedAt: new Date().toISOString(),
    ...data,
  };
  const blob = new Blob([JSON.stringify(backup, null, 2)], { type: 'application/json' });
  const url = URL.createObjectURL(blob);
  const link = document.createElement('a');
  link.href = url;
  link.download = `نسخة-احتياطية-رحلات-الأعلاف-${new Date().toISOString().slice(0, 10)}.json`;
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
  URL.revokeObjectURL(url);
}

function isObject(v: unknown): v is Record<string, unknown> {
  return typeof v === 'object' && v !== null && !Array.isArray(v);
}

/** يقرأ ملف النسخة الاحتياطية ويتحقق منه. يرمي خطأ برسالة عربية إن كان الملف غير صالح. */
export function parseBackup(text: string): AppData {
  let raw: unknown;
  try {
    raw = JSON.parse(text.replace(/^﻿/, ''));
  } catch {
    throw new Error('الملف ليس ملف نسخة احتياطية صالحاً.');
  }
  if (!isObject(raw) || !Array.isArray(raw.trips)) {
    throw new Error('الملف لا يحتوي على بيانات رحلات.');
  }

  const trips: Trip[] = [];
  for (const t of raw.trips) {
    if (!isObject(t) || typeof t.id !== 'string' || typeof t.truckNumber !== 'string') continue;
    trips.push(
      normalizeTrip({
        ...(t as unknown as Trip),
        tripNumber: typeof t.tripNumber === 'string' ? t.tripNumber : '',
        driverName: typeof t.driverName === 'string' ? t.driverName : '',
        farm: typeof t.farm === 'string' ? t.farm : '',
        feedType: typeof t.feedType === 'string' ? t.feedType : '',
      }),
    );
  }

  const trucks = (Array.isArray(raw.trucks) ? raw.trucks : []).filter(
    (x): x is TruckEntry => isObject(x) && typeof x.id === 'string' && typeof x.number === 'string',
  ).map((x) => ({ id: x.id, number: x.number, driverName: typeof x.driverName === 'string' ? x.driverName : '' }));

  const simple = (list: unknown): SimpleEntry[] =>
    (Array.isArray(list) ? list : []).filter(
      (x): x is SimpleEntry => isObject(x) && typeof x.id === 'string' && typeof x.name === 'string',
    ).map((x) => ({ id: x.id, name: x.name }));

  return { trips, trucks, farms: simple(raw.farms), feedTypes: simple(raw.feedTypes) };
}

/**
 * يدمج البيانات المستوردة مع الحالية دون حذف أي شيء:
 * - الرحلة تُتخطى إن كانت موجودة (نفس المعرّف أو نفس رقم الرحلة).
 * - الشاحنات تُضاف بحسب الرقم، والمزارع وأصناف العلف بحسب الاسم.
 */
export function mergeData(current: AppData, incoming: AppData): MergeResult {
  const ids = new Set(current.trips.map((t) => t.id));
  const numbers = new Set(current.trips.map((t) => t.tripNumber.trim()).filter(Boolean));
  const addedTrips: Trip[] = [];
  let skipped = 0;
  for (const t of incoming.trips) {
    const num = t.tripNumber.trim();
    if (ids.has(t.id) || (num && numbers.has(num))) {
      skipped++;
      continue;
    }
    ids.add(t.id);
    if (num) numbers.add(num);
    addedTrips.push(t);
  }

  const truckNumbers = new Set(current.trucks.map((t) => t.number.trim()));
  const newTrucks = incoming.trucks.filter((t) => {
    const n = t.number.trim();
    if (!n || truckNumbers.has(n)) return false;
    truckNumbers.add(n);
    return true;
  });
  // شاحنات الرحلات المستوردة تُضاف للقائمة أيضاً حتى تظهر في القوائم المنسدلة
  for (const t of addedTrips) {
    const n = t.truckNumber.trim();
    if (n && !truckNumbers.has(n)) {
      truckNumbers.add(n);
      newTrucks.push({ id: `truck-import-${n}`, number: n, driverName: t.driverName });
    }
  }

  const addNames = (existing: SimpleEntry[], extra: SimpleEntry[], fromTrips: string[], prefix: string) => {
    const names = new Set(existing.map((e) => e.name.trim()));
    const added: SimpleEntry[] = [];
    for (const e of extra) {
      const n = e.name.trim();
      if (n && !names.has(n)) {
        names.add(n);
        added.push(e);
      }
    }
    for (const n of fromTrips.map((x) => x.trim())) {
      if (n && !names.has(n)) {
        names.add(n);
        added.push({ id: `${prefix}-import-${n}`, name: n });
      }
    }
    return added;
  };
  const newFarms = addNames(current.farms, incoming.farms, addedTrips.map((t) => t.farm), 'farm');
  const newFeeds = addNames(current.feedTypes, incoming.feedTypes, addedTrips.map((t) => t.feedType), 'feed');

  return {
    trips: [...current.trips, ...addedTrips],
    trucks: [...current.trucks, ...newTrucks],
    farms: [...current.farms, ...newFarms],
    feedTypes: [...current.feedTypes, ...newFeeds],
    addedTrips: addedTrips.length,
    skippedTrips: skipped,
    addedTrucks: newTrucks.length,
    addedFarms: newFarms.length,
    addedFeedTypes: newFeeds.length,
  };
}
