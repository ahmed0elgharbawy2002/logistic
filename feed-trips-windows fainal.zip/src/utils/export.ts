import type { Trip } from '../types';
import { STAGES, DURATIONS, STATUS_LABELS } from '../types';
import {
  formatFull,
  formatDuration,
  getDurations,
  getTripStatus,
  breakdownTotalMs,
} from './trip';

function escapeCSV(value: string): string {
  if (!value) return '';
  if (value.includes(',') || value.includes('"') || value.includes('\n')) {
    return `"${value.replace(/"/g, '""')}"`;
  }
  return value;
}

function escapeHTML(value: string): string {
  return value
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;');
}

function downloadFile(content: string, filename: string, mime: string): void {
  const BOM = '﻿';
  const blob = new Blob([BOM + content], { type: mime });
  const url = URL.createObjectURL(blob);
  const link = document.createElement('a');
  link.href = url;
  link.download = filename;
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
  URL.revokeObjectURL(url);
}

function formatBreakdowns(trip: Trip): string {
  if (trip.breakdowns.length === 0) return '';
  return trip.breakdowns
    .map((b, i) => {
      const start = formatFull(b.startTime);
      const end = b.endTime ? formatFull(b.endTime) : 'مستمر';
      const reason = b.reason || 'عطل';
      return `عطل ${i + 1}: ${reason} (${start} → ${end})`;
    })
    .join(' | ');
}

const HEADERS = [
  'رقم الرحلة',
  'رقم الشاحنة',
  'اسم السائق',
  'المزرعة',
  'نوع العلف',
  'الحالة',
  ...STAGES.map((s) => s.shortLabel),
  ...DURATIONS.map((d) => d.label),
  'إجمالي زمن الرحلة',
  'عدد الأعطال',
  'تفاصيل الأعطال',
  'إجمالي زمن الأعطال',
];

function tripToRow(t: Trip): string[] {
  const durations = getDurations(t);
  return [
    t.tripNumber,
    t.truckNumber,
    t.driverName,
    t.farm,
    t.feedType,
    STATUS_LABELS[getTripStatus(t)],
    ...STAGES.map((s) => formatFull(t.stages[s.key])),
    ...DURATIONS.map((d) => formatDuration(durations[d.key])),
    formatDuration(durations.total),
    String(t.breakdowns.length),
    formatBreakdowns(t),
    formatDuration(breakdownTotalMs(t)),
  ];
}

export function exportToCSV(trips: Trip[]): void {
  const rows = trips.map(tripToRow);
  const csv = [HEADERS, ...rows]
    .map((row) => row.map(escapeCSV).join(','))
    .join('\r\n');

  const date = new Date().toISOString().slice(0, 10);
  downloadFile(csv, `رحلات-الأعلاف-${date}.csv`, 'text/csv;charset=utf-8;');
}

export function exportToExcelHTML(trips: Trip[]): void {
  const headerRow = `<tr>${HEADERS.map((h) => `<th style="background:#10b981;color:white;padding:8px;border:1px solid #ccc;font-weight:700;">${escapeHTML(h)}</th>`).join('')}</tr>`;

  const dataRows = trips
    .map((t) => {
      const cells = tripToRow(t);
      return `<tr>${cells.map((c) => `<td style="padding:6px 8px;border:1px solid #ddd;text-align:right;">${c ? escapeHTML(c) : '-'}</td>`).join('')}</tr>`;
    })
    .join('');

  const html = `<html xmlns:o="urn:schemas-microsoft-com:office:office" xmlns:x="urn:schemas-microsoft-com:office:excel" xmlns="http://www.w3.org/TR/REC-html40"><head><meta charset="UTF-8"></head><body><table dir="rtl">${headerRow}${dataRows}</table></body></html>`;

  const date = new Date().toISOString().slice(0, 10);
  downloadFile(html, `رحلات-الأعلاف-${date}.xls`, 'application/vnd.ms-excel;charset=utf-8;');
}
