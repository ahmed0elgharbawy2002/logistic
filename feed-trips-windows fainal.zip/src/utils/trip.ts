import type { Trip, TripStatus, StageKey, DurationInfo } from '../types';
import { STAGES, DURATIONS } from '../types';

const pad = (n: number) => String(n).padStart(2, '0');

/** يحول مدة بالمللي ثانية إلى نص عربي: "2 ساعة و 15 دقيقة" */
export function formatDuration(ms: number | undefined): string {
  if (ms === undefined || !(ms >= 0)) return '';
  const totalMinutes = Math.floor(ms / 60000);
  const hours = Math.floor(totalMinutes / 60);
  const minutes = totalMinutes % 60;
  if (hours > 0) return `${hours} ساعة و ${minutes} دقيقة`;
  return `${minutes} دقيقة`;
}

/** التاريخ والوقت بشكل مختصر للجدول */
export function formatShort(iso: string | undefined): string {
  if (!iso) return '';
  const d = new Date(iso);
  if (isNaN(d.getTime())) return '';
  return d.toLocaleString('ar-EG', {
    day: '2-digit',
    month: '2-digit',
    hour: '2-digit',
    minute: '2-digit',
  });
}

/** التاريخ والوقت كاملاً (مع السنة) للتصدير */
export function formatFull(iso: string | undefined): string {
  if (!iso) return '';
  const d = new Date(iso);
  if (isNaN(d.getTime())) return '';
  return d.toLocaleString('ar-EG', {
    year: 'numeric',
    month: '2-digit',
    day: '2-digit',
    hour: '2-digit',
    minute: '2-digit',
  });
}

/** من ISO إلى قيمة حقل datetime-local (بتوقيت الجهاز) */
export function toInputValue(iso: string | undefined): string {
  if (!iso) return '';
  const d = new Date(iso);
  if (isNaN(d.getTime())) return '';
  return `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}T${pad(d.getHours())}:${pad(d.getMinutes())}`;
}

/** من قيمة حقل datetime-local إلى ISO */
export function fromInputValue(value: string): string | undefined {
  if (!value) return undefined;
  const d = new Date(value);
  if (isNaN(d.getTime())) return undefined;
  return d.toISOString();
}

export function nowInputValue(): string {
  return toInputValue(new Date().toISOString());
}

function diff(a: string | undefined, b: string | undefined): number | undefined {
  if (!a || !b) return undefined;
  const ms = new Date(b).getTime() - new Date(a).getTime();
  return ms >= 0 ? ms : undefined;
}

export type DurationMap = Record<DurationInfo['key'], number | undefined> & {
  total: number | undefined;
};

/** يحسب الأزمنة الخمسة + الإجمالي. أي زمن ناقص أحد طرفيه يبقى فارغاً. */
export function getDurations(trip: Pick<Trip, 'stages'>): DurationMap {
  const result = { total: diff(trip.stages.gateArrival, trip.stages.factoryReturn) } as DurationMap;
  for (const d of DURATIONS) {
    result[d.key] = diff(trip.stages[d.from], trip.stages[d.to]);
  }
  return result;
}

export function hasActiveBreakdown(trip: Trip): boolean {
  return trip.breakdowns.some((b) => !b.endTime);
}

export function breakdownTotalMs(trip: Trip): number {
  return trip.breakdowns.reduce((sum, b) => {
    if (!b.endTime) return sum;
    const ms = new Date(b.endTime).getTime() - new Date(b.startTime).getTime();
    return ms > 0 ? sum + ms : sum;
  }, 0);
}

/** الحالة تُحسب تلقائياً: عطل مفتوح = متعطل، وإلا آخر مرحلة تم تسجيلها */
export function getTripStatus(trip: Trip): TripStatus {
  if (hasActiveBreakdown(trip)) return 'breakdown';
  for (let i = STAGES.length - 1; i >= 0; i--) {
    if (trip.stages[STAGES[i].key]) return STAGES[i].statusAfter;
  }
  return 'new';
}

/** وقت الرحلة للترتيب: أول مرحلة مسجلة، وإلا وقت إنشاء السجل */
export function tripTime(trip: Trip): number {
  for (const s of STAGES) {
    const v = trip.stages[s.key as StageKey];
    if (v) return new Date(v).getTime();
  }
  return new Date(trip.createdAt).getTime();
}

/** آخر رحلة لكل شاحنة (للعرض بنمط "البلاكر") */
export function latestPerTruck(trips: Trip[]): Trip[] {
  const map = new Map<string, Trip>();
  for (const t of trips) {
    const key = t.truckNumber.trim();
    const current = map.get(key);
    if (
      !current ||
      tripTime(t) > tripTime(current) ||
      (tripTime(t) === tripTime(current) && t.createdAt > current.createdAt)
    ) {
      map.set(key, t);
    }
  }
  return [...map.values()];
}

/** تطبيع النص العربي للبحث: يتجاهل التشكيل والهمزات والأرقام الهندية */
export function normalizeText(s: string): string {
  return s
    .toLowerCase()
    .replace(/[ً-ٰٟـ]/g, '')
    .replace(/[أإآ]/g, 'ا')
    .replace(/ى/g, 'ي')
    .replace(/ة/g, 'ه')
    .replace(/[٠-٩]/g, (d) => String('٠١٢٣٤٥٦٧٨٩'.indexOf(d)));
}
