import { useEffect, useState } from 'react';
import { X, Wrench, Play, Square, Clock, AlertTriangle, Trash2 } from 'lucide-react';
import type { Trip, Breakdown } from '../types';
import {
  formatShort,
  formatDuration,
  fromInputValue,
  nowInputValue,
  breakdownTotalMs,
} from '../utils/trip';

interface BreakdownModalProps {
  trip: Trip;
  onClose: () => void;
  onStartBreakdown: (tripId: string, reason: string, startTime: string) => void;
  onEndBreakdown: (tripId: string, breakdownId: string, endTime: string) => void;
  onDeleteBreakdown: (tripId: string, breakdownId: string) => void;
}

export default function BreakdownModal({
  trip,
  onClose,
  onStartBreakdown,
  onEndBreakdown,
  onDeleteBreakdown,
}: BreakdownModalProps) {
  const [reason, setReason] = useState('');
  const [startValue, setStartValue] = useState(() => nowInputValue());
  const [endValue, setEndValue] = useState(() => nowInputValue());
  const [error, setError] = useState('');
  const [confirmDeleteId, setConfirmDeleteId] = useState<string | null>(null);

  const activeBreakdown = trip.breakdowns.find((b) => !b.endTime);
  const completedBreakdowns = trip.breakdowns.filter((b) => b.endTime);

  // عند فتح عطل جديد نقترح وقت الانتهاء = الآن (ويمكن تعديله يدوياً)
  useEffect(() => {
    setEndValue(nowInputValue());
    setError('');
  }, [activeBreakdown?.id]);

  function handleStart() {
    const iso = fromInputValue(startValue);
    if (!iso) {
      setError('أدخل وقت بداية العطل.');
      return;
    }
    setError('');
    onStartBreakdown(trip.id, reason.trim(), iso);
    setReason('');
  }

  function handleEnd(b: Breakdown) {
    const iso = fromInputValue(endValue);
    if (!iso) {
      setError('أدخل وقت نهاية العطل.');
      return;
    }
    if (new Date(iso).getTime() < new Date(b.startTime).getTime()) {
      setError('وقت نهاية العطل لا يمكن أن يسبق وقت بدايته.');
      return;
    }
    setError('');
    onEndBreakdown(trip.id, b.id, iso);
    setStartValue(nowInputValue());
  }

  function handleDelete(id: string) {
    if (confirmDeleteId !== id) {
      setConfirmDeleteId(id);
      return;
    }
    setConfirmDeleteId(null);
    onDeleteBreakdown(trip.id, id);
  }

  const totalBreakdownStr = formatDuration(breakdownTotalMs(trip));
  const inputBase =
    'w-full rounded-xl border-2 border-slate-200 bg-white px-4 py-2.5 text-sm text-slate-800 outline-none transition-all focus:border-red-500 focus:ring-4 focus:ring-red-500/10';

  return (
    <div className="fixed inset-0 z-[100] flex items-center justify-center bg-slate-900/40 p-4 backdrop-blur-sm">
      <div className="flex max-h-[88vh] w-full max-w-md flex-col overflow-hidden rounded-2xl bg-white shadow-2xl animate-fade-in-up">
        {/* Header */}
        <div className="flex items-center justify-between border-b border-slate-100 px-5 py-4">
          <div className="flex items-center gap-2">
            <div className="flex h-9 w-9 items-center justify-center rounded-xl bg-red-100 text-red-600">
              <Wrench className="h-5 w-5" />
            </div>
            <div>
              <h2 className="text-base font-bold text-slate-800">إدارة الأعطال</h2>
              <p className="text-xs text-slate-500">
                {trip.tripNumber ? `رحلة رقم ${trip.tripNumber} — ` : 'بدون رقم رحلة — '}
                {trip.truckNumber}
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="rounded-lg p-1.5 text-slate-400 transition-colors hover:bg-slate-100 hover:text-slate-600"
            title="إغلاق"
          >
            <X className="h-5 w-5" />
          </button>
        </div>

        <div className="flex-1 space-y-4 overflow-y-auto p-5">
          {/* Active Breakdown Alert */}
          {activeBreakdown && (
            <div className="flex items-center gap-3 rounded-xl border border-red-200 bg-red-50 px-4 py-3">
              <AlertTriangle className="h-5 w-5 shrink-0 text-red-600 pulse-soft" />
              <div className="flex-1">
                <p className="text-sm font-bold text-red-700">الشاحنة متوقفة بسبب عطل</p>
                <p className="text-xs text-red-500">
                  بدأ: {formatShort(activeBreakdown.startTime)}
                  {activeBreakdown.reason ? ` — ${activeBreakdown.reason}` : ''}
                </p>
              </div>
            </div>
          )}

          {/* Start New Breakdown */}
          {!activeBreakdown && (
            <div className="space-y-3">
              <input
                type="text"
                value={reason}
                onChange={(e) => setReason(e.target.value)}
                placeholder="سبب العطل (اختياري)"
                className={inputBase}
              />
              <div>
                <label className="mb-1 block text-xs font-semibold text-slate-600">وقت بداية العطل</label>
                <input
                  type="datetime-local"
                  dir="ltr"
                  value={startValue}
                  onChange={(e) => setStartValue(e.target.value)}
                  className={`${inputBase} text-right`}
                  data-field="breakdown-start"
                />
              </div>
              <button
                onClick={handleStart}
                className="flex w-full items-center justify-center gap-2 rounded-xl bg-red-600 py-2.5 text-sm font-bold text-white transition-all hover:bg-red-700 active:scale-[0.98]"
              >
                <Play className="h-4 w-4" />
                تسجيل بداية العطل
              </button>
            </div>
          )}

          {/* End Active Breakdown */}
          {activeBreakdown && (
            <div className="space-y-3">
              <div>
                <label className="mb-1 block text-xs font-semibold text-slate-600">وقت نهاية العطل</label>
                <input
                  type="datetime-local"
                  dir="ltr"
                  value={endValue}
                  onChange={(e) => setEndValue(e.target.value)}
                  className={`${inputBase} text-right`}
                  data-field="breakdown-end"
                />
              </div>
              <button
                onClick={() => handleEnd(activeBreakdown)}
                className="flex w-full items-center justify-center gap-2 rounded-xl bg-emerald-600 py-2.5 text-sm font-bold text-white transition-all hover:bg-emerald-700 active:scale-[0.98]"
              >
                <Square className="h-4 w-4" />
                تسجيل نهاية العطل
              </button>
            </div>
          )}

          {error && (
            <p className="rounded-lg bg-red-50 px-3 py-2 text-xs font-semibold text-red-700" role="alert">
              {error}
            </p>
          )}

          {/* Breakdown History */}
          {completedBreakdowns.length > 0 && (
            <div className="space-y-2 border-t border-slate-100 pt-4">
              <p className="text-xs font-bold text-slate-500">سجل الأعطال</p>
              {completedBreakdowns.map((b: Breakdown) => (
                <div
                  key={b.id}
                  className="rounded-xl border border-slate-100 bg-slate-50/60 px-4 py-3"
                >
                  <div className="flex items-center justify-between gap-2">
                    <span className="text-xs font-semibold text-slate-500">{b.reason || 'عطل'}</span>
                    <div className="flex items-center gap-2">
                      <span className="inline-flex items-center gap-1 rounded-md bg-emerald-100 px-2 py-0.5 text-xs font-bold text-emerald-700">
                        <Clock className="h-3 w-3" />
                        {formatDuration(new Date(b.endTime!).getTime() - new Date(b.startTime).getTime()) ||
                          '0 دقيقة'}
                      </span>
                      <button
                        onClick={() => handleDelete(b.id)}
                        className={`inline-flex items-center gap-1 rounded-md px-1.5 py-0.5 text-xs font-bold transition-colors ${
                          confirmDeleteId === b.id
                            ? 'bg-red-600 text-white'
                            : 'text-slate-300 hover:bg-red-50 hover:text-red-500'
                        }`}
                        title="حذف هذا العطل"
                      >
                        <Trash2 className="h-3.5 w-3.5" />
                        {confirmDeleteId === b.id && 'تأكيد؟'}
                      </button>
                    </div>
                  </div>
                  <div className="mt-1.5 flex items-center gap-2 text-xs text-slate-400">
                    <span>{formatShort(b.startTime)}</span>
                    <span>←</span>
                    <span>{formatShort(b.endTime)}</span>
                  </div>
                </div>
              ))}

              {totalBreakdownStr && (
                <div className="flex items-center justify-between rounded-xl bg-red-50 px-4 py-2.5">
                  <span className="text-xs font-bold text-red-600">إجمالي وقت الأعطال</span>
                  <span className="text-xs font-bold text-red-700">{totalBreakdownStr}</span>
                </div>
              )}
            </div>
          )}

          {trip.breakdowns.length === 0 && !activeBreakdown && (
            <p className="py-2 text-center text-xs text-slate-400">
              لم يتم تسجيل أي أعطال لهذه الرحلة
            </p>
          )}
        </div>
      </div>
    </div>
  );
}
