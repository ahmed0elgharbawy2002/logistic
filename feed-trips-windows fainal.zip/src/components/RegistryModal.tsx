import { useState } from 'react';
import { X, Plus, Trash2, Truck, MapPin, Wheat } from 'lucide-react';
import type { TruckEntry, SimpleEntry } from '../types';

interface RegistryModalProps {
  open: boolean;
  onClose: () => void;
  trucks: TruckEntry[];
  farms: SimpleEntry[];
  feedTypes: SimpleEntry[];
  onTrucksChange: (trucks: TruckEntry[]) => void;
  onFarmsChange: (farms: SimpleEntry[]) => void;
  onFeedTypesChange: (feedTypes: SimpleEntry[]) => void;
}

type Tab = 'trucks' | 'farms' | 'feedTypes';

function genId(prefix: string): string {
  return `${prefix}-${Date.now()}-${Math.random().toString(36).slice(2, 6)}`;
}

export default function RegistryModal({
  open,
  onClose,
  trucks,
  farms,
  feedTypes,
  onTrucksChange,
  onFarmsChange,
  onFeedTypesChange,
}: RegistryModalProps) {
  const [tab, setTab] = useState<Tab>('trucks');
  const [truckNumber, setTruckNumber] = useState('');
  const [truckDriver, setTruckDriver] = useState('');
  const [farmName, setFarmName] = useState('');
  const [feedName, setFeedName] = useState('');

  if (!open) return null;

  function addTruck() {
    if (!truckNumber.trim()) return;
    onTrucksChange([
      ...trucks,
      { id: genId('truck'), number: truckNumber.trim(), driverName: truckDriver.trim() },
    ]);
    setTruckNumber('');
    setTruckDriver('');
  }

  function deleteTruck(id: string) {
    onTrucksChange(trucks.filter((t) => t.id !== id));
  }

  function addFarm() {
    if (!farmName.trim()) return;
    onFarmsChange([...farms, { id: genId('farm'), name: farmName.trim() }]);
    setFarmName('');
  }

  function deleteFarm(id: string) {
    onFarmsChange(farms.filter((f) => f.id !== id));
  }

  function addFeedType() {
    if (!feedName.trim()) return;
    onFeedTypesChange([...feedTypes, { id: genId('feed'), name: feedName.trim() }]);
    setFeedName('');
  }

  function deleteFeedType(id: string) {
    onFeedTypesChange(feedTypes.filter((f) => f.id !== id));
  }

  const tabs: { key: Tab; label: string; icon: typeof Truck }[] = [
    { key: 'trucks', label: 'الشاحنات والسائقين', icon: Truck },
    { key: 'farms', label: 'المزارع', icon: MapPin },
    { key: 'feedTypes', label: 'أصناف العلف', icon: Wheat },
  ];

  const inputBase =
    'w-full rounded-xl border-2 border-slate-200 bg-white px-3 py-2 text-sm text-slate-800 outline-none transition-all focus:border-brand-500 focus:ring-4 focus:ring-brand-500/10';

  return (
    <div className="fixed inset-0 z-[100] flex items-center justify-center bg-slate-900/40 p-4 backdrop-blur-sm">
      <div className="flex max-h-[85vh] w-full max-w-lg flex-col overflow-hidden rounded-2xl bg-white shadow-2xl animate-fade-in-up">
        {/* Header */}
        <div className="flex items-center justify-between border-b border-slate-100 px-5 py-4">
          <h2 className="text-base font-bold text-slate-800">إدارة القوائم</h2>
          <button
            onClick={onClose}
            className="rounded-lg p-1.5 text-slate-400 transition-colors hover:bg-slate-100 hover:text-slate-600"
          >
            <X className="h-5 w-5" />
          </button>
        </div>

        {/* Tabs */}
        <div className="flex gap-1 border-b border-slate-100 px-3 pt-2">
          {tabs.map((t) => {
            const Icon = t.icon;
            return (
              <button
                key={t.key}
                onClick={() => setTab(t.key)}
                className={`flex items-center gap-1.5 rounded-t-lg px-3 py-2 text-xs font-bold transition-all sm:text-sm ${
                  tab === t.key
                    ? 'border-b-2 border-brand-600 text-brand-600'
                    : 'text-slate-400 hover:text-slate-600'
                }`}
              >
                <Icon className="h-4 w-4" />
                {t.label}
              </button>
            );
          })}
        </div>

        {/* Content */}
        <div className="flex-1 overflow-y-auto p-5">
          {/* Trucks Tab */}
          {tab === 'trucks' && (
            <div className="space-y-4">
              <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
                <input
                  type="text"
                  value={truckNumber}
                  onChange={(e) => setTruckNumber(e.target.value)}
                  onKeyDown={(e) => e.key === 'Enter' && (e.preventDefault(), addTruck())}
                  placeholder="رقم الشاحنة (مثال: 4421 DXA)"
                  className={inputBase}
                />
                <input
                  type="text"
                  value={truckDriver}
                  onChange={(e) => setTruckDriver(e.target.value)}
                  onKeyDown={(e) => e.key === 'Enter' && (e.preventDefault(), addTruck())}
                  placeholder="اسم السائق"
                  className={inputBase}
                />
              </div>
              <button
                onClick={addTruck}
                disabled={!truckNumber.trim()}
                className="flex w-full items-center justify-center gap-2 rounded-xl bg-brand-600 py-2.5 text-sm font-bold text-white transition-all hover:bg-brand-700 active:scale-[0.98] disabled:cursor-not-allowed disabled:opacity-40"
              >
                <Plus className="h-4 w-4" />
                إضافة شاحنة
              </button>

              <div className="space-y-2">
                {trucks.length === 0 ? (
                  <p className="py-6 text-center text-xs text-slate-400">لا توجد شاحنات مسجلة</p>
                ) : (
                  trucks.map((truck) => (
                    <div
                      key={truck.id}
                      className="flex items-center justify-between rounded-xl border border-slate-100 bg-slate-50/60 px-4 py-2.5"
                    >
                      <div className="flex items-center gap-3">
                        <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-brand-100 text-brand-600">
                          <Truck className="h-4 w-4" />
                        </div>
                        <div>
                          <p className="text-sm font-bold text-slate-700">{truck.number}</p>
                          <p className="text-xs text-slate-400">
                            {truck.driverName || 'لم يتم تحديد سائق'}
                          </p>
                        </div>
                      </div>
                      <button
                        onClick={() => deleteTruck(truck.id)}
                        className="rounded-lg p-1.5 text-slate-300 transition-all hover:bg-red-50 hover:text-red-500"
                      >
                        <Trash2 className="h-4 w-4" />
                      </button>
                    </div>
                  ))
                )}
              </div>
            </div>
          )}

          {/* Farms Tab */}
          {tab === 'farms' && (
            <div className="space-y-4">
              <div className="flex gap-3">
                <input
                  type="text"
                  value={farmName}
                  onChange={(e) => setFarmName(e.target.value)}
                  onKeyDown={(e) => e.key === 'Enter' && (e.preventDefault(), addFarm())}
                  placeholder="اسم المزرعة"
                  className={inputBase}
                />
                <button
                  onClick={addFarm}
                  disabled={!farmName.trim()}
                  className="flex shrink-0 items-center justify-center gap-2 rounded-xl bg-brand-600 px-4 py-2 text-sm font-bold text-white transition-all hover:bg-brand-700 active:scale-[0.98] disabled:cursor-not-allowed disabled:opacity-40"
                >
                  <Plus className="h-4 w-4" />
                  إضافة
                </button>
              </div>

              <div className="space-y-2">
                {farms.length === 0 ? (
                  <p className="py-6 text-center text-xs text-slate-400">لا توجد مزارع مسجلة</p>
                ) : (
                  farms.map((farm) => (
                    <div
                      key={farm.id}
                      className="flex items-center justify-between rounded-xl border border-slate-100 bg-slate-50/60 px-4 py-2.5"
                    >
                      <div className="flex items-center gap-3">
                        <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-purple-100 text-purple-600">
                          <MapPin className="h-4 w-4" />
                        </div>
                        <p className="text-sm font-bold text-slate-700">{farm.name}</p>
                      </div>
                      <button
                        onClick={() => deleteFarm(farm.id)}
                        className="rounded-lg p-1.5 text-slate-300 transition-all hover:bg-red-50 hover:text-red-500"
                      >
                        <Trash2 className="h-4 w-4" />
                      </button>
                    </div>
                  ))
                )}
              </div>
            </div>
          )}

          {/* Feed Types Tab */}
          {tab === 'feedTypes' && (
            <div className="space-y-4">
              <div className="flex gap-3">
                <input
                  type="text"
                  value={feedName}
                  onChange={(e) => setFeedName(e.target.value)}
                  onKeyDown={(e) => e.key === 'Enter' && (e.preventDefault(), addFeedType())}
                  placeholder="اسم صنف العلف"
                  className={inputBase}
                />
                <button
                  onClick={addFeedType}
                  disabled={!feedName.trim()}
                  className="flex shrink-0 items-center justify-center gap-2 rounded-xl bg-brand-600 px-4 py-2 text-sm font-bold text-white transition-all hover:bg-brand-700 active:scale-[0.98] disabled:cursor-not-allowed disabled:opacity-40"
                >
                  <Plus className="h-4 w-4" />
                  إضافة
                </button>
              </div>

              <div className="space-y-2">
                {feedTypes.length === 0 ? (
                  <p className="py-6 text-center text-xs text-slate-400">لا توجد أصناف مسجلة</p>
                ) : (
                  feedTypes.map((feed) => (
                    <div
                      key={feed.id}
                      className="flex items-center justify-between rounded-xl border border-slate-100 bg-slate-50/60 px-4 py-2.5"
                    >
                      <div className="flex items-center gap-3">
                        <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-amber-100 text-amber-600">
                          <Wheat className="h-4 w-4" />
                        </div>
                        <p className="text-sm font-bold text-slate-700">{feed.name}</p>
                      </div>
                      <button
                        onClick={() => deleteFeedType(feed.id)}
                        className="rounded-lg p-1.5 text-slate-300 transition-all hover:bg-red-50 hover:text-red-500"
                      >
                        <Trash2 className="h-4 w-4" />
                      </button>
                    </div>
                  ))
                )}
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
