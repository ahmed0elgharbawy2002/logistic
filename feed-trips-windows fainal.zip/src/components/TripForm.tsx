import { useState } from 'react';
import { Plus, RotateCcw, Settings, User } from 'lucide-react';
import type { TruckEntry, SimpleEntry, Trip, NewTripData } from '../types';
import { fromInputValue, nowInputValue } from '../utils/trip';

interface TripFormProps {
  onAdd: (trip: NewTripData) => void;
  onClearAll: () => void;
  onOpenSettings: () => void;
  trips: Trip[];
  trucks: TruckEntry[];
  farms: SimpleEntry[];
  feedTypes: SimpleEntry[];
}

export default function TripForm({
  onAdd,
  onClearAll,
  onOpenSettings,
  trips,
  trucks,
  farms,
  feedTypes,
}: TripFormProps) {
  const [tripNumber, setTripNumber] = useState('');
  const [truckId, setTruckId] = useState('');
  const [driverName, setDriverName] = useState('');
  const [driverTouched, setDriverTouched] = useState(false);
  const [farm, setFarm] = useState('');
  const [feedType, setFeedType] = useState('');
  const [arrival, setArrival] = useState(() => nowInputValue());
  const [errors, setErrors] = useState<Record<string, string>>({});

  const selectedTruck = trucks.find((t) => t.id === truckId);
  const tripCount = trips.length;

  function validate(): boolean {
    const e: Record<string, string> = {};
    const num = tripNumber.trim();
    // رقم الرحلة اختياري، لكن إن أُدخل يجب ألا يتكرر
    if (num && trips.some((t) => t.tripNumber.trim() === num)) {
      e.tripNumber = 'رقم الرحلة مستخدم من قبل';
    }
    if (!truckId) e.truckId = 'required';
    if (!driverName.trim()) e.driverName = 'required';
    if (!farm) e.farm = 'required';
    if (!feedType) e.feedType = 'required';
    if (!fromInputValue(arrival)) e.arrival = 'required';
    setErrors(e);
    return Object.keys(e).length === 0;
  }

  function handleSubmit(ev: React.FormEvent) {
    ev.preventDefault();
    if (!validate()) return;
    const truck = trucks.find((t) => t.id === truckId);
    onAdd({
      tripNumber: tripNumber.trim(),
      truckNumber: truck?.number ?? '',
      driverName: driverName.trim(),
      farm,
      feedType,
      gateArrival: fromInputValue(arrival) as string,
    });
    setTripNumber('');
    setTruckId('');
    setDriverName('');
    setDriverTouched(false);
    setFarm('');
    setFeedType('');
    setArrival(nowInputValue());
    setErrors({});
  }

  function handleTruckChange(id: string) {
    setTruckId(id);
    // يتغير اسم السائق تلقائياً مع الشاحنة ما لم يكتبه المستخدم بنفسه
    if (!driverTouched) {
      const truck = trucks.find((t) => t.id === id);
      setDriverName(truck?.driverName ?? '');
    }
  }

  const inputBase =
    'w-full rounded-xl border-2 bg-white px-4 py-2.5 text-sm text-slate-800 transition-all outline-none focus:ring-4';
  const inputOk =
    'border-slate-200 focus:border-brand-500 focus:ring-brand-500/10';
  const inputErr = 'border-red-300 focus:border-red-500 focus:ring-red-500/10';

  const emptyTrucks = trucks.length === 0;
  const emptyFarms = farms.length === 0;
  const emptyFeedTypes = feedTypes.length === 0;

  return (
    <div className="rounded-2xl border border-slate-200 bg-white p-5 shadow-sm sm:p-6">
      <div className="mb-5 flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-brand-500/10 text-brand-600">
            <Plus className="h-5 w-5" />
          </div>
          <div>
            <h2 className="text-lg font-bold text-slate-800">إضافة رحلة جديدة</h2>
            <p className="text-xs text-slate-500">
              سجّل وصول الشاحنة للمصنع، وأكمل باقي الأوقات لاحقاً من زر التعديل في السجل
            </p>
          </div>
        </div>
        <button
          onClick={onOpenSettings}
          className="flex items-center gap-2 rounded-xl border-2 border-slate-200 bg-slate-50 px-3 py-2 text-xs font-bold text-slate-600 transition-all hover:border-brand-300 hover:bg-brand-50 hover:text-brand-600"
          title="إدارة القوائم"
        >
          <Settings className="h-4 w-4" />
          <span className="hidden sm:inline">إدارة القوائم</span>
        </button>
      </div>

      <form onSubmit={handleSubmit} className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-3">
        {/* Trip Number (optional) */}
        <div>
          <label className="mb-1.5 block text-xs font-semibold text-slate-600">
            رقم الرحلة <span className="font-normal text-slate-400">(اختياري — يصدر بعد انتهاء التنزيل)</span>
          </label>
          <input
            type="text"
            value={tripNumber}
            onChange={(e) => setTripNumber(e.target.value)}
            placeholder="يمكن تركه فارغاً وإضافته لاحقاً"
            className={`${inputBase} ${errors.tripNumber ? inputErr : inputOk}`}
          />
          {errors.tripNumber && <p className="mt-1 text-xs text-red-600">{errors.tripNumber}</p>}
        </div>

        {/* Truck Selection */}
        <div>
          <label className="mb-1.5 block text-xs font-semibold text-slate-600">رقم الشاحنة / البلاكر</label>
          <select
            value={truckId}
            onChange={(e) => handleTruckChange(e.target.value)}
            disabled={emptyTrucks}
            className={`${inputBase} ${errors.truckId ? inputErr : inputOk} cursor-pointer disabled:opacity-50`}
          >
            <option value="">اختر شاحنة...</option>
            {trucks.map((t) => (
              <option key={t.id} value={t.id}>
                {t.number}
                {t.driverName ? ` — ${t.driverName}` : ''}
              </option>
            ))}
          </select>
          {emptyTrucks && (
            <p className="mt-1 text-xs text-amber-600">
              لا توجد شاحنات بعد —{' '}
              <button type="button" onClick={onOpenSettings} className="font-bold underline">
                أضف شاحنة من إدارة القوائم
              </button>
            </p>
          )}
        </div>

        {/* Driver Name */}
        <div>
          <label className="mb-1.5 block text-xs font-semibold text-slate-600">اسم السائق</label>
          <div className="relative">
            <input
              type="text"
              value={driverName}
              onChange={(e) => {
                setDriverName(e.target.value);
                setDriverTouched(e.target.value.trim() !== '');
              }}
              placeholder="اسم السائق"
              className={`${inputBase} ${errors.driverName ? inputErr : inputOk} ${selectedTruck?.driverName ? 'pr-10' : ''}`}
            />
            {selectedTruck?.driverName && (
              <div className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-300" title="معبأ تلقائياً من سجل الشاحنة">
                <User className="h-4 w-4" />
              </div>
            )}
          </div>
        </div>

        {/* Farm */}
        <div>
          <label className="mb-1.5 block text-xs font-semibold text-slate-600">المزرعة المستهدفة</label>
          <select
            value={farm}
            onChange={(e) => setFarm(e.target.value)}
            disabled={emptyFarms}
            className={`${inputBase} ${errors.farm ? inputErr : inputOk} cursor-pointer disabled:opacity-50`}
          >
            <option value="">اختر مزرعة...</option>
            {farms.map((f) => (
              <option key={f.id} value={f.name}>
                {f.name}
              </option>
            ))}
          </select>
          {emptyFarms && (
            <p className="mt-1 text-xs text-amber-600">أضف مزارع من زر "إدارة القوائم"</p>
          )}
        </div>

        {/* Feed Type */}
        <div>
          <label className="mb-1.5 block text-xs font-semibold text-slate-600">نوع العلف</label>
          <select
            value={feedType}
            onChange={(e) => setFeedType(e.target.value)}
            disabled={emptyFeedTypes}
            className={`${inputBase} ${errors.feedType ? inputErr : inputOk} cursor-pointer disabled:opacity-50`}
          >
            <option value="">اختر نوع العلف...</option>
            {feedTypes.map((ft) => (
              <option key={ft.id} value={ft.name}>
                {ft.name}
              </option>
            ))}
          </select>
          {emptyFeedTypes && (
            <p className="mt-1 text-xs text-amber-600">أضف أصناف العلف من زر "إدارة القوائم"</p>
          )}
        </div>

        {/* Arrival time (manual) */}
        <div>
          <label className="mb-1.5 block text-xs font-semibold text-slate-600">وقت الوصول للمصنع</label>
          <input
            type="datetime-local"
            dir="ltr"
            value={arrival}
            onChange={(e) => setArrival(e.target.value)}
            className={`${inputBase} ${errors.arrival ? inputErr : inputOk} text-right`}
          />
        </div>

        {/* Buttons */}
        <div className="flex items-end gap-3 sm:col-span-2 lg:col-span-3">
          <button
            type="submit"
            className="flex flex-1 items-center justify-center gap-2 rounded-xl bg-brand-600 px-5 py-2.5 text-sm font-bold text-white shadow-sm transition-all hover:bg-brand-700 active:scale-[0.98]"
          >
            <Plus className="h-4 w-4" />
            إضافة الرحلة
          </button>
          <button
            type="button"
            onClick={onClearAll}
            disabled={tripCount === 0}
            className="flex items-center justify-center gap-2 rounded-xl border-2 border-red-200 bg-red-50 px-4 py-2.5 text-sm font-semibold text-red-600 transition-all hover:bg-red-100 disabled:cursor-not-allowed disabled:opacity-40"
            title="حذف جميع الرحلات"
          >
            <RotateCcw className="h-4 w-4" />
          </button>
        </div>
      </form>
    </div>
  );
}
