import { useMemo, useState } from 'react';
import { X, Pencil, Clock } from 'lucide-react';
import type { Trip, TruckEntry, SimpleEntry, StageKey } from '../types';
import { STAGES, DURATIONS } from '../types';
import {
  fromInputValue,
  toInputValue,
  nowInputValue,
  getDurations,
  formatDuration,
} from '../utils/trip';

interface TripEditModalProps {
  trip: Trip;
  allTrips: Trip[];
  trucks: TruckEntry[];
  farms: SimpleEntry[];
  feedTypes: SimpleEntry[];
  onSave: (trip: Trip) => void;
  onClose: () => void;
}

type TimesState = Record<StageKey, string>;

export default function TripEditModal({
  trip,
  allTrips,
  trucks,
  farms,
  feedTypes,
  onSave,
  onClose,
}: TripEditModalProps) {
  const [tripNumber, setTripNumber] = useState(trip.tripNumber);
  const [truckNumber, setTruckNumber] = useState(trip.truckNumber);
  const [driverName, setDriverName] = useState(trip.driverName);
  const [farm, setFarm] = useState(trip.farm);
  const [feedType, setFeedType] = useState(trip.feedType);
  const [times, setTimes] = useState<TimesState>(
    () =>
      Object.fromEntries(STAGES.map((s) => [s.key, toInputValue(trip.stages[s.key])])) as TimesState,
  );
  const [errors, setErrors] = useState<string[]>([]);

  // القيم الحالية للرحلة قد لا تكون موجودة في القوائم (إن حُذفت منها) فنضيفها للخيارات
  const truckOptions = useMemo(() => {
    const list = trucks.map((t) => ({ value: t.number, label: t.driverName ? `${t.number} — ${t.driverName}` : t.number }));
    if (truckNumber && !list.some((o) => o.value === truckNumber)) {
      list.unshift({ value: truckNumber, label: truckNumber });
    }
    return list;
  }, [trucks, truckNumber]);
  const farmOptions = useMemo(() => {
    const list = farms.map((f) => f.name);
    if (farm && !list.includes(farm)) list.unshift(farm);
    return list;
  }, [farms, farm]);
  const feedOptions = useMemo(() => {
    const list = feedTypes.map((f) => f.name);
    if (feedType && !list.includes(feedType)) list.unshift(feedType);
    return list;
  }, [feedTypes, feedType]);

  // معاينة مباشرة للأزمنة المحسوبة
  const previewDurations = useMemo(() => {
    const stages: Trip['stages'] = {};
    for (const s of STAGES) {
      const iso = fromInputValue(times[s.key]);
      if (iso) stages[s.key] = iso;
    }
    return getDurations({ stages });
  }, [times]);

  function handleTruckChange(number: string) {
    setTruckNumber(number);
    const t = trucks.find((x) => x.number === number);
    if (t?.driverName) setDriverName(t.driverName);
  }

  function setTime(key: StageKey, value: string) {
    setTimes((prev) => ({ ...prev, [key]: value }));
  }

  function validate(): string[] {
    const list: string[] = [];
    const num = tripNumber.trim();
    if (num && allTrips.some((t) => t.id !== trip.id && t.tripNumber.trim() === num)) {
      list.push('رقم الرحلة مستخدم في رحلة أخرى.');
    }
    if (!truckNumber) list.push('اختر الشاحنة.');
    if (!driverName.trim()) list.push('اسم السائق مطلوب.');
    if (!farm) list.push('اختر المزرعة.');
    if (!feedType) list.push('اختر نوع العلف.');

    let prev: { label: string; time: number } | null = null;
    for (const s of STAGES) {
      const iso = fromInputValue(times[s.key]);
      if (!iso) continue;
      const time = new Date(iso).getTime();
      if (prev && time < prev.time) {
        list.push(`"${s.label}" لا يمكن أن يسبق "${prev.label}".`);
      }
      prev = { label: s.label, time };
    }
    return list;
  }

  function handleSave() {
    const problems = validate();
    setErrors(problems);
    if (problems.length > 0) return;

    const stages: Trip['stages'] = {};
    for (const s of STAGES) {
      const value = times[s.key];
      if (!value) continue;
      // إن لم يتغير الوقت نحتفظ بالقيمة الأصلية كما هي (بالثواني)
      const iso =
        value === toInputValue(trip.stages[s.key]) && trip.stages[s.key]
          ? trip.stages[s.key]
          : fromInputValue(value);
      if (iso) stages[s.key] = iso;
    }

    onSave({
      ...trip,
      tripNumber: tripNumber.trim(),
      truckNumber,
      driverName: driverName.trim(),
      farm,
      feedType,
      stages,
    });
  }

  const inputBase =
    'w-full rounded-xl border-2 border-slate-200 bg-white px-3 py-2 text-sm text-slate-800 outline-none transition-all focus:border-brand-500 focus:ring-4 focus:ring-brand-500/10';

  return (
    <div className="fixed inset-0 z-[100] flex items-center justify-center bg-slate-900/40 p-4 backdrop-blur-sm">
      <div className="flex max-h-[92vh] w-full max-w-2xl flex-col overflow-hidden rounded-2xl bg-white shadow-2xl animate-fade-in-up">
        {/* Header */}
        <div className="flex items-center justify-between border-b border-slate-100 px-5 py-4">
          <div className="flex items-center gap-2">
            <div className="flex h-9 w-9 items-center justify-center rounded-xl bg-brand-100 text-brand-600">
              <Pencil className="h-5 w-5" />
            </div>
            <div>
              <h2 className="text-base font-bold text-slate-800">تعديل الرحلة</h2>
              <p className="text-xs text-slate-500">
                {trip.tripNumber ? `رحلة رقم ${trip.tripNumber} — ` : 'بدون رقم رحلة — '}
                {trip.truckNumber}
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="rounded-lg p-1.5 text-slate-400 transition-colors hover:bg-slate-100 hover:text-slate-600"
            title="إغلاق"
          >
            <X className="h-5 w-5" />
          </button>
        </div>

        <div className="flex-1 space-y-5 overflow-y-auto p-5">
          {/* Basic data */}
          <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
            <div>
              <label className="mb-1 block text-xs font-semibold text-slate-600">
                رقم الرحلة <span className="font-normal text-slate-400">(اختياري)</span>
              </label>
              <input
                type="text"
                value={tripNumber}
                onChange={(e) => setTripNumber(e.target.value)}
                placeholder="أضفه بعد صدوره"
                className={inputBase}
                data-field="tripNumber"
              />
            </div>
            <div>
              <label className="mb-1 block text-xs font-semibold text-slate-600">الشاحنة</label>
              <select
                value={truckNumber}
                onChange={(e) => handleTruckChange(e.target.value)}
                className={inputBase}
                data-field="truck"
              >
                <option value="">اختر شاحنة...</option>
                {truckOptions.map((o) => (
                  <option key={o.value} value={o.value}>
                    {o.label}
                  </option>
                ))}
              </select>
            </div>
            <div>
              <label className="mb-1 block text-xs font-semibold text-slate-600">اسم السائق</label>
              <input
                type="text"
                value={driverName}
                onChange={(e) => setDriverName(e.target.value)}
                className={inputBase}
                data-field="driver"
              />
            </div>
            <div>
              <label className="mb-1 block text-xs font-semibold text-slate-600">
                المزرعة <span className="font-normal text-slate-400">(يمكن تغييرها إذا تغيرت الوجهة)</span>
              </label>
              <select
                value={farm}
                onChange={(e) => setFarm(e.target.value)}
                className={inputBase}
                data-field="farm"
              >
                <option value="">اختر مزرعة...</option>
                {farmOptions.map((f) => (
                  <option key={f} value={f}>
                    {f}
                  </option>
                ))}
              </select>
            </div>
            <div>
              <label className="mb-1 block text-xs font-semibold text-slate-600">نوع العلف</label>
              <select
                value={feedType}
                onChange={(e) => setFeedType(e.target.value)}
                className={inputBase}
                data-field="feed"
              >
                <option value="">اختر نوع العلف...</option>
                {feedOptions.map((f) => (
                  <option key={f} value={f}>
                    {f}
                  </option>
                ))}
              </select>
            </div>
          </div>

          {/* Stage times */}
          <div>
            <p className="mb-2 text-xs font-bold text-slate-500">
              أوقات المراحل (تُدخل يدوياً — اترك المرحلة فارغة إن لم تحدث بعد)
            </p>
            <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
              {STAGES.map((s) => (
                <div key={s.key}>
                  <label className="mb-1 block text-xs font-semibold text-slate-600">{s.label}</label>
                  <div className="flex items-center gap-1.5">
                    <input
                      type="datetime-local"
                      dir="ltr"
                      value={times[s.key]}
                      onChange={(e) => setTime(s.key, e.target.value)}
                      className={`${inputBase} text-right`}
                      data-stage={s.key}
                    />
                    <button
                      type="button"
                      onClick={() => setTime(s.key, nowInputValue())}
                      className="shrink-0 rounded-lg border border-slate-200 px-2 py-2 text-xs font-bold text-slate-500 hover:bg-slate-50"
                      title="ضبط الوقت الحالي"
                    >
                      الآن
                    </button>
                    <button
                      type="button"
                      onClick={() => setTime(s.key, '')}
                      disabled={!times[s.key]}
                      className="shrink-0 rounded-lg p-2 text-slate-300 hover:bg-red-50 hover:text-red-500 disabled:opacity-30"
                      title="مسح الوقت"
                    >
                      <X className="h-4 w-4" />
                    </button>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Durations preview */}
          <div className="rounded-xl border border-slate-100 bg-slate-50/70 p-4">
            <p className="mb-2 flex items-center gap-1.5 text-xs font-bold text-slate-500">
              <Clock className="h-4 w-4" />
              الأزمنة المحسوبة تلقائياً
            </p>
            <div className="grid grid-cols-1 gap-x-6 gap-y-1.5 sm:grid-cols-2">
              {DURATIONS.map((d) => (
                <div key={d.key} className="flex items-center justify-between text-xs">
                  <span className="text-slate-500">{d.label}</span>
                  <span className="font-bold text-slate-700" data-duration={d.key}>
                    {formatDuration(previewDurations[d.key]) || '—'}
                  </span>
                </div>
              ))}
              <div className="flex items-center justify-between text-xs sm:col-span-2 sm:border-t sm:border-slate-200 sm:pt-1.5">
                <span className="font-bold text-slate-600">إجمالي زمن الرحلة</span>
                <span className="font-bold text-brand-700" data-duration="total">
                  {formatDuration(previewDurations.total) || '—'}
                </span>
              </div>
            </div>
          </div>

          {errors.length > 0 && (
            <div className="rounded-xl border border-red-200 bg-red-50 px-4 py-3" role="alert">
              <ul className="list-disc space-y-1 pr-4 text-xs font-semibold text-red-700">
                {errors.map((e) => (
                  <li key={e}>{e}</li>
                ))}
              </ul>
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="flex gap-3 border-t border-slate-100 px-5 py-4">
          <button
            onClick={handleSave}
            className="flex-1 rounded-xl bg-brand-600 py-2.5 text-sm font-bold text-white transition-all hover:bg-brand-700 active:scale-[0.98]"
          >
            حفظ التعديلات
          </button>
          <button
            onClick={onClose}
            className="flex-1 rounded-xl border-2 border-slate-200 bg-white py-2.5 text-sm font-bold text-slate-600 transition-all hover:bg-slate-50"
          >
            إلغاء
          </button>
        </div>
      </div>
    </div>
  );
}
