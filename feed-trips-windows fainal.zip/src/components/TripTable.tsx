import { useMemo, useState } from 'react';
import { Truck, Wrench, X, Pencil, Search, ArrowUp, ArrowDown, ArrowUpDown } from 'lucide-react';
import type { Trip, StageKey, TripStatus } from '../types';
import {
  STAGES,
  STATUS_LABELS,
  STATUS_COLORS,
  STATUS_ORDER,
  FILTER_STATUSES,
} from '../types';
import {
  getTripStatus,
  getDurations,
  formatDuration,
  formatShort,
  hasActiveBreakdown,
  latestPerTruck,
  normalizeText,
  tripTime,
} from '../utils/trip';

type ViewMode = 'trips' | 'blocker';
type SortKey =
  | 'tripNumber'
  | 'truckNumber'
  | 'driverName'
  | 'farm'
  | 'feedType'
  | 'status'
  | StageKey
  | 'total'
  | 'breakdowns';
type SortDir = 'asc' | 'desc';

interface Column {
  key: SortKey;
  label: string;
  center?: boolean;
}

const COLUMNS: Column[] = [
  { key: 'tripNumber', label: 'رقم الرحلة' },
  { key: 'truckNumber', label: 'الشاحنة' },
  { key: 'driverName', label: 'السائق' },
  { key: 'farm', label: 'المزرعة' },
  { key: 'feedType', label: 'العلف' },
  { key: 'status', label: 'الحالة' },
  ...STAGES.map((s) => ({ key: s.key as SortKey, label: s.shortLabel, center: true })),
  { key: 'total', label: 'إجمالي الزمن', center: true },
  { key: 'breakdowns', label: 'أعطال', center: true },
];

function sortValue(trip: Trip, key: SortKey): string | number | undefined {
  switch (key) {
    case 'tripNumber':
      return trip.tripNumber.trim() || undefined;
    case 'truckNumber':
    case 'driverName':
    case 'farm':
    case 'feedType':
      return trip[key] || undefined;
    case 'status':
      return STATUS_ORDER.indexOf(getTripStatus(trip));
    case 'total':
      return getDurations(trip).total;
    case 'breakdowns':
      return trip.breakdowns.length;
    default: {
      const iso = trip.stages[key];
      return iso ? new Date(iso).getTime() : undefined;
    }
  }
}

function compareValues(a: string | number, b: string | number): number {
  if (typeof a === 'number' && typeof b === 'number') return a - b;
  return String(a).localeCompare(String(b), 'ar', { numeric: true });
}

function searchHaystack(trip: Trip): string {
  return normalizeText(
    [
      trip.tripNumber,
      trip.truckNumber,
      trip.driverName,
      trip.farm,
      trip.feedType,
      STATUS_LABELS[getTripStatus(trip)],
      ...trip.breakdowns.map((b) => b.reason ?? ''),
    ].join(' '),
  );
}

interface TripTableProps {
  trips: Trip[];
  onEdit: (trip: Trip) => void;
  onRequestDelete: (trip: Trip) => void;
  onBreakdownClick: (trip: Trip) => void;
}

export default function TripTable({ trips, onEdit, onRequestDelete, onBreakdownClick }: TripTableProps) {
  const [view, setView] = useState<ViewMode>('trips');
  const [statusFilter, setStatusFilter] = useState<'all' | TripStatus>('all');
  const [query, setQuery] = useState('');
  const [sort, setSort] = useState<{ key: SortKey; dir: SortDir } | null>(null);

  const blockerTrips = useMemo(() => latestPerTruck(trips), [trips]);
  const baseTrips = view === 'blocker' ? blockerTrips : trips;

  // البحث يُطبق أولاً، وأعداد أزرار الفلتر تعكس نتيجة البحث
  const searched = useMemo(() => {
    const tokens = normalizeText(query).split(/\s+/).filter(Boolean);
    if (tokens.length === 0) return baseTrips;
    return baseTrips.filter((t) => {
      const hay = searchHaystack(t);
      const haySquashed = hay.replace(/\s+/g, '');
      return tokens.every((tok) => hay.includes(tok) || haySquashed.includes(tok));
    });
  }, [baseTrips, query]);

  const counts = useMemo(() => {
    const c: Record<string, number> = { all: searched.length };
    for (const t of searched) {
      const s = getTripStatus(t);
      c[s] = (c[s] ?? 0) + 1;
    }
    return c;
  }, [searched]);

  const rows = useMemo(() => {
    const filtered =
      statusFilter === 'all' ? searched : searched.filter((t) => getTripStatus(t) === statusFilter);
    const sorted = [...filtered];
    if (!sort) {
      sorted.sort((a, b) => tripTime(b) - tripTime(a));
    } else {
      sorted.sort((x, y) => {
        const a = sortValue(x, sort.key);
        const b = sortValue(y, sort.key);
        if (a === undefined && b === undefined) return 0;
        if (a === undefined) return 1; // الفارغ دائماً في النهاية
        if (b === undefined) return -1;
        const c = compareValues(a, b);
        return sort.dir === 'asc' ? c : -c;
      });
    }
    return sorted;
  }, [searched, statusFilter, sort]);

  function toggleSort(key: SortKey) {
    setSort((prev) => {
      if (!prev || prev.key !== key) return { key, dir: 'asc' };
      if (prev.dir === 'asc') return { key, dir: 'desc' };
      return null; // الضغطة الثالثة تعيد الترتيب الافتراضي (الأحدث أولاً)
    });
  }

  if (trips.length === 0) {
    return (
      <div className="flex flex-col items-center justify-center rounded-2xl border border-dashed border-slate-300 bg-white py-16">
        <div className="mb-3 flex h-16 w-16 items-center justify-center rounded-2xl bg-slate-100">
          <Truck className="h-8 w-8 text-slate-400" />
        </div>
        <p className="text-sm font-semibold text-slate-600">لا توجد رحلات مسجلة بعد</p>
        <p className="mt-1 text-xs text-slate-400">أضف رحلة جديدة من النموذج أعلاه لبدء التتبع</p>
      </div>
    );
  }

  const chipBase =
    'inline-flex items-center gap-1.5 rounded-full border px-3 py-1.5 text-xs font-bold transition-all';

  return (
    <div className="overflow-hidden rounded-2xl border border-slate-200 bg-white shadow-sm">
      {/* Title + main view switch + search */}
      <div className="flex flex-wrap items-center justify-between gap-3 border-b border-slate-100 px-5 py-4">
        <div className="flex flex-wrap items-center gap-3">
          <h2 className="text-lg font-bold text-slate-800">سجلات الرحلات</h2>
          <div className="inline-flex rounded-xl bg-slate-100 p-1" role="tablist" aria-label="طريقة العرض">
            <button
              role="tab"
              aria-selected={view === 'trips'}
              onClick={() => setView('trips')}
              data-view="trips"
              className={`rounded-lg px-4 py-1.5 text-xs font-bold transition-all ${
                view === 'trips' ? 'bg-white text-brand-700 shadow-sm' : 'text-slate-500 hover:text-slate-700'
              }`}
            >
              الرحلات ({trips.length})
            </button>
            <button
              role="tab"
              aria-selected={view === 'blocker'}
              onClick={() => setView('blocker')}
              data-view="blocker"
              title="آخر رحلة لكل سيارة — لمعرفة أين توجد السيارات الآن"
              className={`rounded-lg px-4 py-1.5 text-xs font-bold transition-all ${
                view === 'blocker' ? 'bg-white text-brand-700 shadow-sm' : 'text-slate-500 hover:text-slate-700'
              }`}
            >
              البلاكر ({blockerTrips.length})
            </button>
          </div>
        </div>

        <div className="relative w-full sm:w-72">
          <Search className="pointer-events-none absolute right-3 top-1/2 h-4 w-4 -translate-y-1/2 text-slate-400" />
          <input
            type="search"
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="بحث: رقم رحلة، شاحنة، سائق، مزرعة..."
            className="w-full rounded-xl border-2 border-slate-200 bg-white py-2 pr-9 pl-3 text-sm text-slate-800 outline-none transition-all focus:border-brand-500 focus:ring-4 focus:ring-brand-500/10"
            data-field="search"
          />
        </div>
      </div>

      {view === 'blocker' && (
        <p className="border-b border-slate-100 bg-brand-50/50 px-5 py-2 text-xs text-brand-800">
          يعرض آخر رحلة لكل سيارة فقط، لتعرف أين توجد كل سيارة الآن.
        </p>
      )}

      {/* Sub filter by status */}
      <div className="flex flex-wrap items-center gap-2 border-b border-slate-100 px-5 py-3" role="group" aria-label="فلتر الحالة">
        <button
          onClick={() => setStatusFilter('all')}
          data-filter="all"
          className={`${chipBase} ${
            statusFilter === 'all'
              ? 'border-brand-600 bg-brand-600 text-white'
              : 'border-slate-200 bg-white text-slate-600 hover:bg-slate-50'
          }`}
        >
          الكل <span className="opacity-80">({counts.all ?? 0})</span>
        </button>
        {FILTER_STATUSES.map((s) => (
          <button
            key={s}
            onClick={() => setStatusFilter(s)}
            data-filter={s}
            className={`${chipBase} ${
              statusFilter === s
                ? 'border-brand-600 bg-brand-600 text-white'
                : `${STATUS_COLORS[s]} hover:brightness-95`
            }`}
          >
            {STATUS_LABELS[s]} <span className="opacity-80">({counts[s] ?? 0})</span>
          </button>
        ))}
      </div>

      {rows.length === 0 ? (
        <div className="py-14 text-center">
          <p className="text-sm font-semibold text-slate-600">لا توجد نتائج مطابقة</p>
          <p className="mt-1 text-xs text-slate-400">جرّب تغيير كلمة البحث أو فلتر الحالة</p>
        </div>
      ) : (
        <div className="overflow-x-auto">
          <table className="w-full min-w-[1350px] text-right">
            <thead>
              <tr className="border-b border-slate-100 bg-slate-50/80 text-xs font-bold text-slate-500">
                {COLUMNS.map((col) => {
                  const active = sort?.key === col.key;
                  const Icon = !active ? ArrowUpDown : sort?.dir === 'asc' ? ArrowUp : ArrowDown;
                  return (
                    <th
                      key={col.key}
                      className={`px-3 py-3 ${col.center ? 'text-center' : ''}`}
                      aria-sort={active ? (sort?.dir === 'asc' ? 'ascending' : 'descending') : 'none'}
                    >
                      <button
                        onClick={() => toggleSort(col.key)}
                        data-sort={col.key}
                        title="اضغط للترتيب"
                        className={`inline-flex items-center gap-1 rounded-md px-1 py-0.5 transition-colors hover:bg-slate-100 ${
                          active ? 'text-brand-700' : ''
                        }`}
                      >
                        {col.label}
                        <Icon className={`h-3.5 w-3.5 ${active ? '' : 'opacity-40'}`} />
                      </button>
                    </th>
                  );
                })}
                <th className="px-3 py-3 text-center">إجراءات</th>
              </tr>
            </thead>
            <tbody>
              {rows.map((trip) => {
                const status = getTripStatus(trip);
                const activeBreakdown = hasActiveBreakdown(trip);
                const breakdownCount = trip.breakdowns.length;
                const total = getDurations(trip).total;
                return (
                  <tr
                    key={trip.id}
                    className={`group border-b border-slate-50 text-sm transition-colors hover:bg-slate-50/50 ${activeBreakdown ? 'bg-red-50/30' : ''}`}
                  >
                    <td className="px-3 py-3 font-bold text-slate-800">
                      {trip.tripNumber || <span className="text-xs font-normal text-slate-300">بدون رقم</span>}
                    </td>
                    <td className="px-3 py-3 font-semibold text-slate-700">{trip.truckNumber}</td>
                    <td className="px-3 py-3 text-slate-600">{trip.driverName}</td>
                    <td className="px-3 py-3 text-slate-600">{trip.farm}</td>
                    <td className="px-3 py-3">
                      <span className="rounded-md bg-slate-100 px-2 py-0.5 text-xs font-semibold text-slate-600">
                        {trip.feedType}
                      </span>
                    </td>
                    <td className="px-3 py-3" data-cell="status">
                      <span
                        className={`inline-flex items-center rounded-full border px-2.5 py-1 text-xs font-bold ${STATUS_COLORS[status]}`}
                      >
                        {status !== 'completed' && status !== 'new' && (
                          <span className="ml-1 h-1.5 w-1.5 rounded-full bg-current pulse-soft" />
                        )}
                        {STATUS_LABELS[status]}
                      </span>
                    </td>

                    {STAGES.map((stage) => {
                      const time = trip.stages[stage.key];
                      return (
                        <td key={stage.key} className="px-2 py-3 text-center">
                          <button
                            onClick={() => onEdit(trip)}
                            title="اضغط لإدخال الوقت أو تعديله"
                            className={
                              time
                                ? 'inline-flex items-center rounded-lg bg-emerald-50 px-2 py-1 text-xs font-semibold text-emerald-700 transition-colors hover:bg-emerald-100'
                                : 'inline-flex items-center rounded-lg px-2.5 py-1 text-xs font-bold text-slate-300 transition-colors hover:bg-slate-100 hover:text-slate-500'
                            }
                          >
                            {time ? formatShort(time) : '— إدخال'}
                          </button>
                        </td>
                      );
                    })}

                    <td className="px-3 py-3 text-center" data-cell="total">
                      {total !== undefined ? (
                        <span className="inline-flex items-center rounded-lg bg-brand-50 px-2 py-1 text-xs font-bold text-brand-700">
                          {formatDuration(total)}
                        </span>
                      ) : (
                        <span className="text-xs text-slate-300">--</span>
                      )}
                    </td>

                    <td className="px-3 py-3 text-center">
                      <button
                        onClick={() => onBreakdownClick(trip)}
                        className={`inline-flex items-center gap-1.5 rounded-lg px-2.5 py-1.5 text-xs font-bold transition-all active:scale-95 ${
                          activeBreakdown
                            ? 'bg-red-600 text-white shadow-sm hover:bg-red-700'
                            : breakdownCount > 0
                              ? 'bg-amber-100 text-amber-700 hover:bg-amber-200'
                              : 'border border-slate-200 text-slate-500 hover:bg-slate-50'
                        }`}
                        title="إدارة الأعطال"
                      >
                        <Wrench className="h-3.5 w-3.5" />
                        <span>{breakdownCount > 0 ? breakdownCount : 'عطل'}</span>
                      </button>
                    </td>

                    <td className="px-3 py-3 text-center">
                      <div className="inline-flex items-center gap-1">
                        <button
                          onClick={() => onEdit(trip)}
                          className="inline-flex items-center justify-center rounded-lg p-1.5 text-slate-400 transition-all hover:bg-brand-50 hover:text-brand-600"
                          title="تعديل الرحلة"
                          data-action="edit"
                        >
                          <Pencil className="h-4 w-4" />
                        </button>
                        <button
                          onClick={() => onRequestDelete(trip)}
                          className="inline-flex items-center justify-center rounded-lg p-1.5 text-slate-300 transition-all hover:bg-red-50 hover:text-red-500"
                          title="حذف الرحلة"
                          data-action="delete"
                        >
                          <X className="h-4 w-4" />
                        </button>
                      </div>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}
