export type StageKey =
  | 'gateArrival'
  | 'loadingStart'
  | 'departure'
  | 'farmArrival'
  | 'unloadingDone'
  | 'factoryReturn';

export type TripStatus =
  | 'new'
  | 'waiting'
  | 'loading'
  | 'on_road'
  | 'unloading'
  | 'returning'
  | 'completed'
  | 'breakdown';

export interface Breakdown {
  id: string;
  startTime: string;
  endTime?: string;
  reason?: string;
}

export interface Trip {
  id: string;
  /** اختياري عند الإضافة، لأن رقم الرحلة يصدر بعد انتهاء التنزيل */
  tripNumber: string;
  truckNumber: string;
  driverName: string;
  farm: string;
  feedType: string;
  /** أوقات المراحل (ISO) — تُدخل يدوياً وكلها اختيارية */
  stages: Partial<Record<StageKey, string>>;
  createdAt: string;
  breakdowns: Breakdown[];
}

export interface NewTripData {
  tripNumber: string;
  truckNumber: string;
  driverName: string;
  farm: string;
  feedType: string;
  /** وقت الوصول للمصنع (ISO) */
  gateArrival: string;
}

export interface StageInfo {
  key: StageKey;
  label: string;
  shortLabel: string;
  /** الحالة التي تصبح عليها الرحلة بعد تسجيل هذه المرحلة */
  statusAfter: TripStatus;
}

export interface DurationInfo {
  key: 'waiting' | 'loading' | 'going' | 'unloading' | 'returning';
  label: string;
  from: StageKey;
  to: StageKey;
}

export interface TruckEntry {
  id: string;
  number: string;
  driverName: string;
}

export interface SimpleEntry {
  id: string;
  name: string;
}

export const DEFAULT_FARMS: string[] = [
  'الوطن',
  'نقوة وطن',
  'الجابري',
  'فالا 1',
  'فالا 2',
  'مزايا',
  'القرية الخضراء',
];

export const DEFAULT_FEED_TYPES: string[] = ['بادي', 'نامي', 'ناهي'];

export const STAGES: StageInfo[] = [
  {
    key: 'gateArrival',
    label: 'الوصول للمصنع (بداية الانتظار)',
    shortLabel: 'الوصول للمصنع',
    statusAfter: 'waiting',
  },
  {
    key: 'loadingStart',
    label: 'بداية التحميل',
    shortLabel: 'بداية التحميل',
    statusAfter: 'loading',
  },
  {
    key: 'departure',
    label: 'الخروج للمزرعة (نهاية التحميل)',
    shortLabel: 'الخروج للمزرعة',
    statusAfter: 'on_road',
  },
  {
    key: 'farmArrival',
    label: 'الوصول للمزرعة (بداية التنزيل)',
    shortLabel: 'الوصول للمزرعة',
    statusAfter: 'unloading',
  },
  {
    key: 'unloadingDone',
    label: 'انتهاء التنزيل',
    shortLabel: 'انتهاء التنزيل',
    statusAfter: 'returning',
  },
  {
    key: 'factoryReturn',
    label: 'العودة للمصنع (إغلاق الرحلة)',
    shortLabel: 'العودة للمصنع',
    statusAfter: 'completed',
  },
];

/** الأزمنة الخمسة التي تُحسب تلقائياً من أوقات المراحل */
export const DURATIONS: DurationInfo[] = [
  { key: 'waiting', label: 'زمن الانتظار أمام المصنع', from: 'gateArrival', to: 'loadingStart' },
  { key: 'loading', label: 'زمن التحميل', from: 'loadingStart', to: 'departure' },
  { key: 'going', label: 'زمن الذهاب إلى المزرعة', from: 'departure', to: 'farmArrival' },
  { key: 'unloading', label: 'زمن التنزيل', from: 'farmArrival', to: 'unloadingDone' },
  { key: 'returning', label: 'زمن الرجوع للمصنع', from: 'unloadingDone', to: 'factoryReturn' },
];

export const STATUS_LABELS: Record<TripStatus, string> = {
  new: 'لم تبدأ',
  waiting: 'انتظار أمام المصنع',
  loading: 'على التحميل',
  on_road: 'بالطريق إلى المزرعة',
  unloading: 'على التنزيل',
  returning: 'راجع للمصنع',
  completed: 'مكتملة',
  breakdown: 'متعطل',
};

/** ترتيب الحالات (يُستخدم في الترتيب وفي أزرار الفلتر) */
export const STATUS_ORDER: TripStatus[] = [
  'new',
  'waiting',
  'loading',
  'on_road',
  'unloading',
  'returning',
  'completed',
  'breakdown',
];

/** أزرار الفلتر الفرعي (بالترتيب المطلوب) */
export const FILTER_STATUSES: TripStatus[] = [
  'waiting',
  'loading',
  'on_road',
  'unloading',
  'returning',
  'breakdown',
  'completed',
];

export const STATUS_COLORS: Record<TripStatus, string> = {
  new: 'bg-slate-100 text-slate-600 border-slate-200',
  waiting: 'bg-blue-100 text-blue-700 border-blue-200',
  loading: 'bg-cyan-100 text-cyan-700 border-cyan-200',
  on_road: 'bg-amber-100 text-amber-700 border-amber-200',
  unloading: 'bg-purple-100 text-purple-700 border-purple-200',
  returning: 'bg-orange-100 text-orange-700 border-orange-200',
  completed: 'bg-emerald-100 text-emerald-700 border-emerald-200',
  breakdown: 'bg-red-100 text-red-700 border-red-200',
};
