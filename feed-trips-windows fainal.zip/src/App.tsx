import { useState, useEffect, useMemo, useRef } from 'react';
import {
  Truck,
  FileSpreadsheet,
  Download,
  Upload,
  Save,
  BarChart3,
  ClipboardList,
  Wrench,
} from 'lucide-react';
import type { Trip, TruckEntry, SimpleEntry, NewTripData } from './types';
import { DEFAULT_FARMS, DEFAULT_FEED_TYPES } from './types';
import {
  loadTrips, saveTrips,
  loadTrucks, saveTrucks,
  loadFarms, saveFarms,
  loadFeedTypes, saveFeedTypes,
} from './utils/storage';
import { exportToCSV, exportToExcelHTML } from './utils/export';
import { getTripStatus } from './utils/trip';
import { downloadBackup, parseBackup, mergeData } from './utils/backup';
import TripForm from './components/TripForm';
import TripTable from './components/TripTable';
import TripEditModal from './components/TripEditModal';
import RegistryModal from './components/RegistryModal';
import BreakdownModal from './components/BreakdownModal';
import ConfirmDialog from './components/ConfirmDialog';

function generateId(prefix: string): string {
  return `${prefix}-${Date.now()}-${Math.random().toString(36).slice(2, 8)}`;
}

function initFarms(): SimpleEntry[] {
  return DEFAULT_FARMS.map((name, i) => ({ id: `farm-default-${i}`, name }));
}

function initFeedTypes(): SimpleEntry[] {
  return DEFAULT_FEED_TYPES.map((name, i) => ({ id: `feed-default-${i}`, name }));
}

export default function App() {
  // القراءة من التخزين تتم مرة واحدة عند بدء البرنامج
  const [trips, setTrips] = useState<Trip[]>(() => loadTrips());
  const [trucks, setTrucks] = useState<TruckEntry[]>(() => loadTrucks());
  const [farms, setFarms] = useState<SimpleEntry[]>(() => {
    const loaded = loadFarms();
    return loaded.length > 0 ? loaded : initFarms();
  });
  const [feedTypes, setFeedTypes] = useState<SimpleEntry[]>(() => {
    const loaded = loadFeedTypes();
    return loaded.length > 0 ? loaded : initFeedTypes();
  });

  const [registryOpen, setRegistryOpen] = useState(false);
  const [editTripId, setEditTripId] = useState<string | null>(null);
  const [breakdownTripId, setBreakdownTripId] = useState<string | null>(null);
  const [deleteTarget, setDeleteTarget] = useState<Trip | null>(null);
  const [clearAllOpen, setClearAllOpen] = useState(false);

  const [notice, setNotice] = useState<{ type: 'ok' | 'error'; text: string } | null>(null);
  const importInputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    if (!notice) return;
    const timer = setTimeout(() => setNotice(null), 8000);
    return () => clearTimeout(timer);
  }, [notice]);

  useEffect(() => { saveTrips(trips); }, [trips]);
  useEffect(() => { saveTrucks(trucks); }, [trucks]);
  useEffect(() => { saveFarms(farms); }, [farms]);
  useEffect(() => { saveFeedTypes(feedTypes); }, [feedTypes]);

  const editTrip = trips.find((t) => t.id === editTripId) ?? null;
  const breakdownTrip = trips.find((t) => t.id === breakdownTripId) ?? null;

  function handleAdd(data: NewTripData) {
    const newTrip: Trip = {
      id: generateId('trip'),
      tripNumber: data.tripNumber,
      truckNumber: data.truckNumber,
      driverName: data.driverName,
      farm: data.farm,
      feedType: data.feedType,
      stages: { gateArrival: data.gateArrival },
      createdAt: new Date().toISOString(),
      breakdowns: [],
    };
    setTrips((prev) => [newTrip, ...prev]);
  }

  function handleUpdate(updated: Trip) {
    setTrips((prev) => prev.map((t) => (t.id === updated.id ? updated : t)));
    setEditTripId(null);
  }

  function handleConfirmDelete() {
    if (deleteTarget) {
      const id = deleteTarget.id;
      setTrips((prev) => prev.filter((t) => t.id !== id));
    }
    setDeleteTarget(null);
  }

  function handleBackup() {
    downloadBackup({ trips, trucks, farms, feedTypes });
    setNotice({ type: 'ok', text: 'تم تنزيل النسخة الاحتياطية. احفظ الملف في مكان آمن.' });
  }

  function handleImportFile(e: React.ChangeEvent<HTMLInputElement>) {
    const file = e.target.files?.[0];
    e.target.value = ''; // للسماح باختيار نفس الملف مرة أخرى
    if (!file) return;
    const reader = new FileReader();
    reader.onload = () => {
      try {
        const incoming = parseBackup(String(reader.result));
        const merged = mergeData({ trips, trucks, farms, feedTypes }, incoming);
        setTrips(merged.trips);
        setTrucks(merged.trucks);
        setFarms(merged.farms);
        setFeedTypes(merged.feedTypes);
        const parts = [`تم استيراد ${merged.addedTrips} رحلة`];
        if (merged.skippedTrips > 0) parts.push(`وتخطي ${merged.skippedTrips} رحلة موجودة مسبقاً`);
        const extras = merged.addedTrucks + merged.addedFarms + merged.addedFeedTypes;
        if (extras > 0) {
          parts.push(
            `وإضافة ${merged.addedTrucks} شاحنة و${merged.addedFarms} مزرعة و${merged.addedFeedTypes} صنف علف للقوائم`,
          );
        }
        setNotice({ type: 'ok', text: parts.join(' ') + '.' });
      } catch (err) {
        setNotice({ type: 'error', text: err instanceof Error ? err.message : 'تعذر قراءة الملف.' });
      }
    };
    reader.onerror = () => setNotice({ type: 'error', text: 'تعذر قراءة الملف.' });
    reader.readAsText(file);
  }

  function handleConfirmClearAll() {
    setTrips([]);
    setClearAllOpen(false);
  }

  function handleStartBreakdown(tripId: string, reason: string, startTime: string) {
    setTrips((prev) =>
      prev.map((t) => {
        if (t.id !== tripId) return t;
        if (t.breakdowns.some((b) => !b.endTime)) return t; // عطل مفتوح بالفعل
        return {
          ...t,
          breakdowns: [
            ...t.breakdowns,
            { id: generateId('breakdown'), startTime, reason: reason || undefined },
          ],
        };
      }),
    );
  }

  function handleEndBreakdown(tripId: string, breakdownId: string, endTime: string) {
    setTrips((prev) =>
      prev.map((t) =>
        t.id !== tripId
          ? t
          : {
              ...t,
              breakdowns: t.breakdowns.map((b) => (b.id === breakdownId ? { ...b, endTime } : b)),
            },
      ),
    );
  }

  function handleDeleteBreakdown(tripId: string, breakdownId: string) {
    setTrips((prev) =>
      prev.map((t) =>
        t.id !== tripId ? t : { ...t, breakdowns: t.breakdowns.filter((b) => b.id !== breakdownId) },
      ),
    );
  }

  const stats = useMemo(() => {
    const statuses = trips.map(getTripStatus);
    return {
      total: trips.length,
      active: statuses.filter((s) => s !== 'completed').length,
      completed: statuses.filter((s) => s === 'completed').length,
      breakdowns: statuses.filter((s) => s === 'breakdown').length,
    };
  }, [trips]);

  return (
    <div className="min-h-screen bg-slate-100">
      {/* Header */}
      <header className="sticky top-0 z-50 border-b border-slate-200 bg-white/90 shadow-sm backdrop-blur-md">
        <div className="mx-auto flex max-w-[1700px] items-center justify-between px-4 py-3 sm:px-6">
          <div className="flex items-center gap-3">
            <div className="flex h-11 w-11 items-center justify-center rounded-2xl bg-brand-600 text-white shadow-lg shadow-brand-600/20">
              <Truck className="h-6 w-6" />
            </div>
            <div>
              <h1 className="text-base font-bold leading-tight text-slate-800 sm:text-lg">
                نظام تتبع رحلات الأعلاف
              </h1>
              <p className="text-xs text-slate-500">مصنع الأعلاف — لوحة إدارة المشرف</p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <input
              ref={importInputRef}
              type="file"
              accept=".json,application/json"
              onChange={handleImportFile}
              className="hidden"
              data-field="import-file"
            />
            <button
              onClick={() => importInputRef.current?.click()}
              title="استيراد بيانات من ملف نسخة احتياطية"
              data-action="import"
              className="flex items-center gap-2 rounded-xl border-2 border-slate-200 bg-white px-3 py-2 text-xs font-bold text-slate-600 shadow-sm transition-all hover:border-brand-300 hover:bg-brand-50 hover:text-brand-700 active:scale-[0.98] sm:px-4 sm:text-sm"
            >
              <Upload className="h-4 w-4" />
              <span className="hidden lg:inline">استيراد</span>
            </button>
            <button
              onClick={handleBackup}
              title="تنزيل نسخة احتياطية من كل البيانات"
              data-action="backup"
              className="flex items-center gap-2 rounded-xl border-2 border-slate-200 bg-white px-3 py-2 text-xs font-bold text-slate-600 shadow-sm transition-all hover:border-brand-300 hover:bg-brand-50 hover:text-brand-700 active:scale-[0.98] sm:px-4 sm:text-sm"
            >
              <Save className="h-4 w-4" />
              <span className="hidden lg:inline">نسخة احتياطية</span>
            </button>
            <button
              onClick={() => exportToCSV(trips)}
              disabled={trips.length === 0}
              className="flex items-center gap-2 rounded-xl bg-emerald-600 px-3 py-2 text-xs font-bold text-white shadow-sm transition-all hover:bg-emerald-700 active:scale-[0.98] disabled:cursor-not-allowed disabled:opacity-40 sm:px-4 sm:text-sm"
            >
              <Download className="h-4 w-4" />
              <span className="hidden sm:inline">تصدير CSV</span>
            </button>
            <button
              onClick={() => exportToExcelHTML(trips)}
              disabled={trips.length === 0}
              className="flex items-center gap-2 rounded-xl bg-brand-600 px-3 py-2 text-xs font-bold text-white shadow-sm transition-all hover:bg-brand-700 active:scale-[0.98] disabled:cursor-not-allowed disabled:opacity-40 sm:px-4 sm:text-sm"
            >
              <FileSpreadsheet className="h-4 w-4" />
              <span className="hidden sm:inline">تصدير وسحب البيانات كملف Excel</span>
              <span className="sm:hidden">Excel</span>
            </button>
          </div>
        </div>
      </header>

      {/* Main */}
      <main className="mx-auto max-w-[1700px] space-y-6 px-4 py-6 sm:px-6 sm:py-8">
        {/* Stats Cards */}
        <div className="grid grid-cols-2 gap-4 sm:grid-cols-4" data-section="stats">
          <div className="rounded-2xl border border-slate-200 bg-white p-4 shadow-sm">
            <div className="mb-2 flex items-center justify-between">
              <span className="text-xs font-semibold text-slate-500">إجمالي الرحلات</span>
              <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-slate-100 text-slate-600">
                <ClipboardList className="h-4 w-4" />
              </div>
            </div>
            <p className="text-2xl font-bold text-slate-800">{stats.total}</p>
          </div>

          <div className="rounded-2xl border border-slate-200 bg-white p-4 shadow-sm">
            <div className="mb-2 flex items-center justify-between">
              <span className="text-xs font-semibold text-slate-500">رحلات نشطة</span>
              <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-amber-100 text-amber-600">
                <Truck className="h-4 w-4" />
              </div>
            </div>
            <p className="text-2xl font-bold text-amber-600">{stats.active}</p>
          </div>

          <div className="rounded-2xl border border-slate-200 bg-white p-4 shadow-sm">
            <div className="mb-2 flex items-center justify-between">
              <span className="text-xs font-semibold text-slate-500">رحلات مكتملة</span>
              <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-emerald-100 text-emerald-600">
                <BarChart3 className="h-4 w-4" />
              </div>
            </div>
            <p className="text-2xl font-bold text-emerald-600">{stats.completed}</p>
          </div>

          <div className="rounded-2xl border border-slate-200 bg-white p-4 shadow-sm">
            <div className="mb-2 flex items-center justify-between">
              <span className="text-xs font-semibold text-slate-500">شاحنات متوقفة للعطل</span>
              <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-red-100 text-red-600">
                <Wrench className="h-4 w-4" />
              </div>
            </div>
            <p className="text-2xl font-bold text-red-600">{stats.breakdowns}</p>
          </div>
        </div>

        {/* Trip Form */}
        <TripForm
          onAdd={handleAdd}
          onClearAll={() => setClearAllOpen(true)}
          onOpenSettings={() => setRegistryOpen(true)}
          trips={trips}
          trucks={trucks}
          farms={farms}
          feedTypes={feedTypes}
        />

        {/* Trip Table */}
        <TripTable
          trips={trips}
          onEdit={(trip) => setEditTripId(trip.id)}
          onRequestDelete={setDeleteTarget}
          onBreakdownClick={(trip) => setBreakdownTripId(trip.id)}
        />

        {/* Footer */}
        <footer className="pt-2 text-center">
          <p className="text-xs text-slate-400">
            يتم حفظ البيانات تلقائياً على هذا الجهاز — لن تضيع عند إغلاق البرنامج أو تحديث الصفحة
          </p>
        </footer>
      </main>

      {/* Notice (import / backup result) */}
      {notice && (
        <div
          role="status"
          data-notice={notice.type}
          className={`fixed bottom-5 left-1/2 z-[300] flex max-w-lg -translate-x-1/2 items-start gap-3 rounded-xl px-4 py-3 text-sm font-semibold shadow-xl ${
            notice.type === 'ok' ? 'bg-emerald-600 text-white' : 'bg-red-600 text-white'
          }`}
        >
          <span className="flex-1">{notice.text}</span>
          <button onClick={() => setNotice(null)} className="text-xs font-bold opacity-80 hover:opacity-100">
            إغلاق
          </button>
        </div>
      )}

      {/* Modals */}
      <RegistryModal
        open={registryOpen}
        onClose={() => setRegistryOpen(false)}
        trucks={trucks}
        farms={farms}
        feedTypes={feedTypes}
        onTrucksChange={setTrucks}
        onFarmsChange={setFarms}
        onFeedTypesChange={setFeedTypes}
      />

      {editTrip && (
        <TripEditModal
          key={editTrip.id}
          trip={editTrip}
          allTrips={trips}
          trucks={trucks}
          farms={farms}
          feedTypes={feedTypes}
          onSave={handleUpdate}
          onClose={() => setEditTripId(null)}
        />
      )}

      {breakdownTrip && (
        <BreakdownModal
          key={breakdownTrip.id}
          trip={breakdownTrip}
          onClose={() => setBreakdownTripId(null)}
          onStartBreakdown={handleStartBreakdown}
          onEndBreakdown={handleEndBreakdown}
          onDeleteBreakdown={handleDeleteBreakdown}
        />
      )}

      <ConfirmDialog
        open={deleteTarget !== null}
        title="حذف الرحلة"
        message={
          deleteTarget
            ? `هل أنت متأكد من حذف ${deleteTarget.tripNumber ? `الرحلة رقم ${deleteTarget.tripNumber}` : 'هذه الرحلة'} (${deleteTarget.truckNumber})؟ لا يمكن التراجع عن هذا الإجراء.`
            : ''
        }
        onConfirm={handleConfirmDelete}
        onCancel={() => setDeleteTarget(null)}
      />

      <ConfirmDialog
        open={clearAllOpen}
        title="حذف جميع الرحلات"
        message={`هل أنت متأكد من حذف جميع الرحلات (${trips.length} رحلة)؟ لا يمكن التراجع عن هذا الإجراء.`}
        confirmLabel="نعم، احذف الكل"
        onConfirm={handleConfirmClearAll}
        onCancel={() => setClearAllOpen(false)}
      />
    </div>
  );
}
