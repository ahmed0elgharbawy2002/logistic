@echo off
echo ============================================
echo   Building Feed Trips Tracker for Windows
echo ============================================
echo.

where node >nul 2>nul
if errorlevel 1 (
  echo [ERROR] Node.js is not installed. Download it from https://nodejs.org then run this file again.
  pause
  exit /b 1
)

echo [1/2] Installing packages... (may take a few minutes)
call npm install
if errorlevel 1 goto fail

echo.
echo [2/2] Building the program...
call npm run electron:build
if errorlevel 1 goto fail

echo.
echo Done! Your program files are in the "release" folder.
start "" release
pause
exit /b 0

:fail
echo.
echo [ERROR] Something failed. Take a screenshot of the error above and send it to me.
pause
exit /b 1
